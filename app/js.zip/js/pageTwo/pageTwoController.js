app.controller('PageTwoController', ['$scope',
	function ($scope) {
		$scope.title = 'Create Homework Assignment';
	}]);