app.controller('PageTwoController', ['$scope',
	function ($scope) {
		$scope.title = 'PageTwo bruh';
	}]);