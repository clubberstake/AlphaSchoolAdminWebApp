app.controller('PageThreeController', ['$scope', '$location',
    function ($scope, $location) {

    }]);