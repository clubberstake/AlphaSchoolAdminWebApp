app.controller('HomeController', ['$scope',
	function ($scope) {
		$scope.entryBox = 'type in the box';
	}]);