app.controller('ViewAnnouncementController', ['$scope', '$location',
    function ($scope, $location) {

    }]);