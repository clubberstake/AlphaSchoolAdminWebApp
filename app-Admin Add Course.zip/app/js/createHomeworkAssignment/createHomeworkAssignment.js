app.controller('CreateHomeworkAssignmentController', ['$scope',
	function ($scope) {
		$scope.title = 'PageTwo bruh';
	}]);