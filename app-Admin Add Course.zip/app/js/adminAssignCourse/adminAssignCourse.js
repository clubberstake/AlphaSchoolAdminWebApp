app.controller('AdminAssignCourseController', ['$scope', '$location',
    function ($scope, $location) {

    }]);