app.controller('ViewCalendarEventController', ['$scope', '$location',
    function ($scope, $location) {

    }]);