app.controller('CreateAnnouncementController', ['$scope', '$location',
    function ($scope, $location) {

    }]);