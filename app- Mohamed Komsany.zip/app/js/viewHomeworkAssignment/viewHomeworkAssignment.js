app.controller('ViewHomeworkAssignmentController', ['$scope', '$location',
    function ($scope, $location) {
       
    }]);