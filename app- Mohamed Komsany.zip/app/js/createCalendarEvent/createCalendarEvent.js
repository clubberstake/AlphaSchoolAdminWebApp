app.controller('CreateCalendarEventController', ['$scope', '$location',
    function ($scope, $location) {
$scope.selectrecip=[
    {name:'class', value:'1'}
    {name:'grade', value:'2'}
    {name:'teacher', value:'3'}
];
$scope.selectrecip =0;
    }]);
    